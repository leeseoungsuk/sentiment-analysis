#ifndef MAINSERVER_H
#define MAINSERVER_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QtNetwork>
#include <QHostAddress>
#include <QDebug>
#include <QString>
#include <QMessageBox>
#include <QFileDialog>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

QT_BEGIN_NAMESPACE
namespace Ui { class MainServer; }
QT_END_NAMESPACE

class MainServer : public QMainWindow
{
    Q_OBJECT

public:
    MainServer(QWidget *parent = nullptr);
    ~MainServer();

private:
    Ui::MainServer *ui;
    void initialize();
    QString serverIP;
    QString serverPort;
    QTcpServer *tcpServer;
    QTcpSocket *tcpSocket;
    QSet<QTcpSocket*> mainSokets;

    QSqlDatabase db;
    QString result_index; // 결과치 이미지 인덱스 저장
    QString result_text; // 결과치 텍스트 저장
    QString result_id; // 결과치 아이디 저장
    QString last_result;

    QString foundName;
    QString foundPh;
    QString foundDay;

signals:
    void singal_newMessage(QString);

private slots:
    void newConnection2();
    void processRequest(QTcpSocket *clientSocket);
    void slot_readSocket();
    void slot_displayMessage(const QString& str);
    void readMessage();
};
#endif // MAINSERVER_H
