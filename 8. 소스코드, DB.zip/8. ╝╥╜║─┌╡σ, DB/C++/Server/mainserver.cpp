#include "mainserver.h"
#include "ui_mainserver.h"

MainServer::MainServer(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainServer)
{
    ui->setupUi(this);
    initialize();
}

MainServer::~MainServer()
{
    delete ui;
}

void MainServer::initialize()
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:/Users/zian/Downloads/main/main/Server/server.db");
    if (!db.open()) {   // DB 연결이 안되면
        qDebug() << "Database Error: " << db.lastError().text();
    }

    QStringList tables = db.tables();
    for (const QString& table : tables) {
        qDebug() << "Table: " << table;
    }

    QHostAddress hostAddress;
    hostAddress = QHostAddress(QHostAddress::LocalHost);

    tcpServer = new QTcpServer(this);

    if (!tcpServer->listen(hostAddress, 25000)) { // 연결 실패 했을때
        QMessageBox::critical(this, tr("TCP Server"), tr("서버를 시작할 수 없습니다. 에러메세지 : %1.").arg(tcpServer->errorString()));
        close();
        return; // 실패시 종료
    }

    ui->labelStatus->setText(tr("서버 동작 중 \n\n" "IP : %1\n" "PORT : %2\n").arg(hostAddress.toString()).arg(tcpServer->serverPort()));

    connect(tcpServer, SIGNAL(newConnection()), this, SLOT(newConnection2()));
    connect(this, &MainServer::singal_newMessage, this, &MainServer::slot_displayMessage);

    // 이건 파이썬 서버와 접속할 때 사용할 소켓
    tcpSocket = new QTcpSocket(this);
    connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(readMessage()));
    connect(tcpSocket, SIGNAL(disconnected()), this, SLOT(disconnected()));
}

void MainServer::newConnection2()
{
    QMessageBox::information(this, tr("접속 완료"), tr("클라이언트가 성공적으로 연결되었습니다."));
    // appendToSocketList 함수로 연결 객체 관리 처리
    while (tcpServer->hasPendingConnections())
        processRequest(tcpServer->nextPendingConnection()); // 메인소켓이라는 리스트에 연결된 소켓들 저장
}

void MainServer::processRequest(QTcpSocket *clientSocket)
{
    mainSokets.insert(clientSocket);
    connect(clientSocket, &QTcpSocket::readyRead, this, &MainServer::slot_readSocket);
}

void MainServer::readMessage()
{
    QMessageBox::information(this, tr("접속 완료"), tr("오 왔다"));
    QTcpSocket* socket = qobject_cast<QTcpSocket*>(sender());
    if (!socket) {
        return;
    }

    QByteArray buffer = socket->readAll();
    QString dataAsString = QString::fromUtf8(buffer);  // QByteArray를 QString으로 변환

    QStringList parts = dataAsString.split(":"); // QString을 쉼표로 나눕니다.

    QString emotion = parts[0];
    QString result_ = parts[1];
    qDebug()<< result_;
    last_result = result_;

    if (emotion == "emotion")
    {
        QString header = QString("Type:emotion,result:%1;").arg(result_);
        qDebug() << header;
        header.resize(1024);

        QByteArray byteArray = header.toUtf8();

        for (QTcpSocket* clientSocket : mainSokets)
        {
            QDataStream socketStream(clientSocket);
            socketStream.setVersion(QDataStream::Qt_5_15);
            socketStream << byteArray;
        }

        QDateTime currentDateTime = QDateTime::currentDateTime();
        QString formattedDate = currentDateTime.toString("yyyy.MM.dd hh:mm:ss");
        QSqlQuery query(db);
        query.prepare("INSERT INTO Result (text, id, result, xy, day) VALUES (:text, :id, :result, :image, :day)");

        query.bindValue(":text", result_text);
        query.bindValue(":id", result_id);
        query.bindValue(":result", last_result);
        query.bindValue(":image", result_index);
        query.bindValue(":day", formattedDate);

        if (query.exec()) {
            qDebug() << "Result Data inserted successfully!";
        } else {
            qDebug() << "Error: " << query.lastError().text();
        }
    }
    if (emotion == "end")
    {
        QString header = QString("Type:end,result:%1;").arg(result_); // 텍스트
        qDebug() << header;
        header.resize(1024);

        QByteArray byteArray = header.toUtf8();

        for (QTcpSocket* clientSocket : mainSokets)
        {
            QDataStream socketStream(clientSocket);
            socketStream.setVersion(QDataStream::Qt_5_15);
            socketStream << byteArray;
        }
    }
}

void MainServer::slot_readSocket()
{
    QTcpSocket* socket = reinterpret_cast<QTcpSocket*>(sender());

    QByteArray buffer;

    QDataStream socketStream(socket);
    socketStream.setVersion(QDataStream::Qt_5_15);

    socketStream.startTransaction();
    socketStream >> buffer;

    if(!socketStream.commitTransaction())
    {
        QString message = QString("%1 :: Waiting for more data to come..").arg(socket->socketDescriptor());
        emit singal_newMessage(message);
        return;
    }

    QString header = buffer.mid(0,1024);   // 첫번째 구분자
    QString Type = header.split(",")[0].split(":")[1];

    buffer = buffer.mid(1024);

    if(Type=="login")  // 클라에서 메시지를 보내면 실행
    {
        QString ID = header.split(",")[1].split(":")[1];
        QString PW = header.split(",")[2].split(":")[1].split(";")[0];
        QSqlQuery query(db);
        query.prepare("SELECT name, ph, day FROM Login WHERE id = :id");
        query.bindValue(":id", ID);
        if (query.exec() && query.next()) {
            // 해당 휴대폰 번호와 일치하는 레코드를 찾았을 때            
            foundName = query.value(0).toString();
            foundPh = query.value(1).toString();
            foundDay = query.value(2).toString();

            result_id = ID; // 결과치 테이블 이름 저장
            qDebug() << result_id;
        } else {
            qDebug() << "No matching record found for the provided phone number.";
        }

        query.prepare("SELECT id, pw FROM Login WHERE id = :id AND pw = :pw");
        query.bindValue(":id", ID);
        query.bindValue(":pw", PW);
        if (query.exec() && query.next()) {
            qDebug() << "Data inserted successfully!";
            // 성공 메시지 보내기
            QDataStream socketStream(socket);
            socketStream.setVersion(QDataStream::Qt_5_15);

            QString header = QString("Type:loginsucess,Id:%1, Pw:%2, Name:%3, Ph:%4, Day:%5;").arg(ID).arg(PW).arg(foundName).arg(foundPh).arg(foundDay);
            header.resize(1024);

            QByteArray byteArray = header.toUtf8();
            socketStream << byteArray;
        } else {
            qDebug() << "ID and PW do not match any record in the database.";
            QDataStream socketStream(socket);
            socketStream.setVersion(QDataStream::Qt_5_15);

            QString header = QString("Type:loginfail,");
            header.resize(1024);

            QByteArray byteArray = header.toUtf8();
            socketStream << byteArray;
        }
    }
    else if(Type == "Sign")
    {
        QString ID = header.split(",")[1].split(":")[1];
        QString PW = header.split(",")[2].split(":")[1];
        QString PH = header.split(",")[3].split(":")[1];
        QString NAME = header.split(",")[4].split(":")[1].split(";")[0];

        QSqlQuery query(db);
        query.prepare("SELECT id FROM Login WHERE id = :id");
        query.bindValue(":id", ID);
        if (query.exec() && query.next()) {
            qDebug() << "Error: 아이디 중복!";
            // 중복 메시지를 클라이언트에게 보내기
            QDataStream socketStream(socket);
            socketStream.setVersion(QDataStream::Qt_5_15);
            QString header = QString("Type:SignupError,");
            header.resize(1024);
            QByteArray byteArray = header.toUtf8();
            socketStream << byteArray;
        }
        else
        {
            QDateTime currentDateTime = QDateTime::currentDateTime();
            QString formattedDate = currentDateTime.toString("yyyy.MM.dd");

            query.prepare("INSERT INTO Login (id, pw, ph, name, day) VALUES (:id, :pw, :ph, :name, :day)");
            query.bindValue(":id", ID);
            query.bindValue(":pw", PW);
            query.bindValue(":ph", PH);
            query.bindValue(":name", NAME);
            query.bindValue(":day", formattedDate);

            if (query.exec()) {
                qDebug() << "Data inserted successfully!";
                // 성공 메시지 보내기
                QDataStream socketStream(socket);
                socketStream.setVersion(QDataStream::Qt_5_15);

                QString header = QString("Type:Signsucess,");
                header.resize(1024);

                QByteArray byteArray = header.toUtf8();
                socketStream << byteArray;
            }
            else {
                qDebug() << "Error: " << query.lastError().text();
            }
        }
    }
    else if(Type == "IdFind")
    {
        QString PH = header.split(",")[1].split(":")[1].split(";")[0]; // 휴대폰 값 받기

        QSqlQuery query(db);
        query.prepare("SELECT id, day FROM Login WHERE ph = :ph");
        query.bindValue(":ph", PH);

        if (query.exec() && query.next()) {
            // 해당 휴대폰 번호와 일치하는 레코드를 찾았을 때
            QString foundID = query.value(0).toString();
            QString foundDay = query.value(1).toString();
            qDebug() << foundID;
            qDebug() << foundDay;
            QDataStream socketStream(socket);
            socketStream.setVersion(QDataStream::Qt_5_15);
            QString header = QString("Type:Idsucess,ID:%1,Day:%2;").arg(foundID).arg(foundDay);
            header.resize(1024);

            QByteArray byteArray = header.toUtf8();
            socketStream << byteArray;
        } else {
            qDebug() << "No matching record found for the provided phone number.";
            // 클라이언트에게 에러 메시지를 보내거나 다른 작업을 수행할 수 있습니다.
        }
    }
    else if(Type == "Pwfind")
    {
        QString ID = header.split(",")[1].split(":")[1];
        QString NAME = header.split(",")[2].split(":")[1].split(";")[0];

        QSqlQuery query(db);
        query.prepare("SELECT pw FROM Login WHERE id = :id AND name = :name");
        query.bindValue(":id", ID);
        query.bindValue(":name", NAME);

        if (query.exec() && query.next()) {
            QString foundPw = query.value(0).toString();

            QDataStream socketStream(socket);
            socketStream.setVersion(QDataStream::Qt_5_15);
            QString header = QString("Type:Pwsucess,Pw:%1;").arg(foundPw);
            header.resize(1024);

            QByteArray byteArray = header.toUtf8();
            socketStream << byteArray;
        } else {
            qDebug() << "No matching record found for the provided phone number.";
            // 클라이언트에게 에러 메시지를 보내거나 다른 작업을 수행할 수 있습니다.
        }
    }
    else if(Type == "test")
    {
        // 파이썬 서버 접속 수정 부분
        serverIP = "10.10.21.115"; //ip
        serverPort = "9999";   // port

        QHostAddress serverAddress(serverIP);
        tcpSocket->connectToHost(serverAddress, serverPort.toUShort());

        QString text = header.split(",")[1].split(":")[1];
        QString imgindex = header.split(",")[2].split(":")[1].split(";")[0];
        result_text = text; // 텍스트 저장
        result_index = imgindex;  // 이미지 인덱스 저장
        QString Python = QString("Type:test, text:%1, randomIndex:%2;").arg(text).arg(imgindex);

        QByteArray byteArray = Python.toUtf8();
        tcpSocket->write(byteArray);

        qDebug() << byteArray;
    }
    else if (Type == "last_result")
    {
        QSqlQuery query(db);
        query.prepare("SELECT result, text, xy, day FROM Result WHERE id = :user_id");
        query.bindValue(":user_id", result_id);

        if (query.exec()) {
            QStringList resultList; // 결과 데이터를 저장할 QStringList
            int maxSize = 4; // 원하는 결과 데이터 크기
            while (query.next())
            {
                QString result = query.value(0).toString();
                QString text = query.value(1).toString();
                QString xy = query.value(2).toString();
                QString day = query.value(3).toString();

                // 결과 데이터를 리스트에 추가
                resultList << result + "@" + text + "@" + xy + "@" + day + "@";  // 끝에 "@"추가
            }

            if (resultList.size() > maxSize) {
                resultList = resultList.mid(0, maxSize);
            }

            QDataStream socketStream(socket);
            socketStream.setVersion(QDataStream::Qt_5_15);
            QString header = "Type:last_result," + resultList.join(";"); // 결과 데이터를 쉼표로 구분하여 합침
            qDebug() << header;
            header.resize(1024);

            QByteArray byteArray = header.toUtf8();
            socketStream << byteArray;
        } else {
            qDebug() << "오류: " << query.lastError().text();
        }
    }
}

void MainServer::slot_displayMessage(const QString& str)
{
    ui->txt_main->append(str);
}

