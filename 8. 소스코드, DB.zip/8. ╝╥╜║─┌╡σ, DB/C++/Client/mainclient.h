#ifndef MAINCLIENT_H
#define MAINCLIENT_H

#include <QMainWindow>
#include <QAbstractSocket>
#include <QDebug>
#include <QFile>
#include <QFileDialog>
#include <QHostAddress>
#include <QMessageBox>
#include <QMetaType>
#include <QString>
#include <QStandardPaths>
#include <QTcpSocket>
#include <QTimer>
#include <QRandomGenerator>
#include <QRegularExpression>
#include <QLabel>
#include <QMovie>
#include <QJsonDocument>


QT_BEGIN_NAMESPACE
namespace Ui { class MainClient; }
QT_END_NAMESPACE

class MainClient : public QMainWindow
{
    Q_OBJECT

public:
    MainClient(QWidget *parent = nullptr);
    ~MainClient();

    int showImage();
    void unnamed();
    void showResult();
    void information();
    void clearResult();

private:
    Ui::MainClient *ui;
    QTcpSocket* tcpSocket;
    QString serverIP;
    QString serverPort;
    QString randomCodeStr;
    QString randomCodeIdfind;

    QString ID; // id 찾기에서 나온 id
    QString Day; // id 찾기에서 나온 Day

    QString user_id;
    QString user_pw;
    QString user_name;
    QString user_ph;
    QString user_day;

    QStringList imageFiles;
    int randomIndex; // 이미지인덱스 저장할 변수

signals:
    void signal_newMessage(QString);

private slots:
    void initialize();
    void slot_readMessage();

    void on_btn_login_clicked();
    void on_btn_sign_clicked();
    void on_btn_checknum_clicked();
    void on_btn_sign_last_clicked();
    void on_btn_sign_last_2_clicked();
    void on_btn_idfind_clicked();
    void on_btn_number_clicked();
    void on_btn_pw_find_clicked();
    void on_btn_pwfind_clicked();
    void on_btnImage_clicked();
    void on_btnSend_clicked();
    void on_btnMyinfo_clicked();
    void on_btnMyinfo2_clicked();
    void on_btn_sign_back_clicked();
    void on_btn_sign_back_2_clicked();
    void on_btn_sign_back_3_clicked();
    void on_btn_sign_back_4_clicked();
    void on_btn_sign_back_5_clicked();
    void on_btn_sign_back_6_clicked();
    void on_btn_sign_back_7_clicked();
    void on_btnRecord_clicked();
    void on_btnLogout1_clicked();
    void on_btnLogout2_clicked();
    void on_btnLogout3_clicked();
    void on_btnMyinfo1_clicked();
    void on_pushButton_3_clicked();
};
#endif // MAINCLIENT_H
