#include "mainclient.h"
#include "ui_mainclient.h"

MainClient::MainClient(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainClient)
{
    ui->setupUi(this);
    initialize();
    ui->stackedWidget->setCurrentIndex(0);
}

MainClient::~MainClient()
{
    delete ui;
}

void MainClient::initialize() //실행될 때 연결
{
    tcpSocket = new QTcpSocket(this); // 연결 소켓 생성

    serverIP = "127.0.0.1"; //ip
    serverPort = "25000";   // port
    QHostAddress serverAddress(serverIP);
    tcpSocket->connectToHost(serverAddress, serverPort.toUShort());

    connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(slot_readMessage()));
    connect(tcpSocket, SIGNAL(disconnected()), this, SLOT(disconnected()));
}

void MainClient::slot_readMessage()   // 서버에서 데이터 받는 곳
{
    QByteArray buffer;
    QDataStream socketStream(tcpSocket);
    socketStream.setVersion(QDataStream::Qt_5_15); // 데이터를 주고 받기 위해 클라랑 서버랑 버전 맞춰주기

    socketStream.startTransaction(); // 데이터를 안전하게 송수신하거나 오류가 발생할 때 되돌리기 사용가능
    socketStream >> buffer;

    if(!socketStream.commitTransaction()) // 데이터가 오고 있을 때 받을 수 있게 해줌
    {
        return;
    }
    QString header = buffer.mid(0,1024);
    QString Type = header.split(",")[0].split(":")[1];
    qDebug() << Type;
    buffer = buffer.mid(1024);

    if(Type=="loginsucess") //로그인 버튼을 누르고 서버에서 로그인 성공을 보내면
    {
        user_id = header.split(",")[1].split(":")[1]; // 내정보
        user_pw = header.split(",")[2].split(":")[1]; // 내정보
        user_name = header.split(",")[3].split(":")[1]; // 내정보
        user_ph = header.split(",")[4].split(":")[1]; // 내정보
        user_day = header.split(",")[5].split(":")[1].split(";")[0]; // 내정보

        QMessageBox::information(this, "Login", "Login successful");

        //여기 빼야함 임시
        QDataStream socketStream(tcpSocket);
        socketStream.setVersion(QDataStream::Qt_5_15);

        QString header = QString("Type:last_result,name:%1;").arg(user_name);
        header.resize(1024);

        QByteArray byteArray = header.toUtf8();
        socketStream << byteArray;
        //여기까지

        ui->stackedWidget->setCurrentIndex(7);
        int currentPageIndex = ui->stackedWidget->currentIndex();

        if (currentPageIndex == 7) {
            randomIndex = showImage();
        }
    }    
    else if(Type == "Signsucess")
    {
        QMessageBox::information(this, "회원가입", "회원가입이 완료되었습니다.");
        int targetIndex = 0;
        ui->stackedWidget->setCurrentIndex(targetIndex);
    }
    else if(Type == "Idsucess") // 아이디찾기 성공적으로 반환
    {
        ID = header.split(",")[1].split(":")[1];
        Day = header.split(",")[2].split(":")[1].split(";")[0];
        qDebug() << ID;
        qDebug() << Day;
        int targetIndex = 3; // 회원가입 인덱스
        ui->stackedWidget->setCurrentIndex(targetIndex);

        ui->lbl_id->setText(ID);
        ui->lbl_day->setText(Day);
    }
    else if(Type == "Pwsucess") // 비밀번호찾기 성공적으로 반환
    {
        QString Pw = header.split(",")[1].split(":")[1].split(";")[0];
        QMessageBox::information(this, "비밀번호", "비밀번호:" + Pw);
        ui->txt_pw_find->clear();
        ui->txt_pw_find2->clear();
        int targetIndex = 0;
        ui->stackedWidget->setCurrentIndex(targetIndex);
    }
    else if(Type == "loginfail")
    {
        ui->lbl_loginfail->setText("로그인 실패");
    }
    else if(Type == "SignupError")
    {
        QMessageBox::information(this, "오류", "아이디 중복");
        ui->txt_sign_id->clear();
    }
    else if(Type == "end")
    {
        QString result = header.split(",")[1].split(":")[1].split(";")[0]; // 형용사 오류
        qDebug() << result;
        ui->result_txt->setText(result + "\n테스트창에서 형용사를 포함해 다시 입력해주세요.");
    }
    else if(Type == "emotion")
    {
        QString result = header.split(",")[1].split(":")[1].split(";")[0];
        qDebug() << result;
        ui->result_txt->setText("이 그림에 대한 당신의 감정은 " + result + "입니다");

        //여기서 내 아이디에 대해서 결과 요청 내정보-> 이때까지 결과 받아야해서
        QDataStream socketStream(tcpSocket);
        socketStream.setVersion(QDataStream::Qt_5_15);

        QString header = QString("Type:last_result,name:%1;").arg(user_name);
        header.resize(1024);

        QByteArray byteArray = header.toUtf8();
        socketStream << byteArray;
    }
    else if(Type == "last_result")
    {
        QString data = header.split(",")[1]; // 데이터 부분 추출
        qDebug() << data;
        QStringList resultList = data.split(";"); // 쉼표로 구분된 결과 데이터를 다시 리스트로 분할
        qDebug() << resultList;

        for (int i = 0; i < 4; ++i)
        {
            if (i < resultList.size())
            {
                QStringList resultFields = resultList[i].split("@"); // 각 값들을 "@"로 구분
                if (resultFields.size() >= 4)
                {
                    QString result = resultFields[0];
                    qDebug() << result;
                    QString text = resultFields[1];
                    qDebug() << text;
                    QString xy = resultFields[2];
                    qDebug() << xy;
                    QString day = resultFields[3];
                    qDebug() << day;

                    if (i == 0) {
                        ui->test_date1->setText(day);
                        ui->test_text1->setText("이 그림에 대한 당신의 감정은\n" + result + "입니다.");
                        int index = xy.toInt();
                        qDebug() << index;
                        QString randomImage = imageFiles[index];
                        ui->test_image1->setPixmap(QPixmap(randomImage));
                        ui->test_image1->setScaledContents(true); // 이미지를 QLabel 크기에 맞춤
                    } else if (i == 1) {
                        ui->test_date2->setText(day);
                        ui->test_text2->setText("이 그림에 대한 당신의 감정은\n" + result + "입니다.");
                        int index = xy.toInt();
                        QString randomImage = imageFiles[index];
                        ui->test_image2->setPixmap(QPixmap(randomImage));
                        ui->test_image2->setScaledContents(true); // 이미지를 QLabel 크기에 맞춤
                    } else if (i == 2) {
                        ui->test_date3->setText(day);
                        ui->test_text3->setText("이 그림에 대한 당신의 감정은\n" + result + "입니다.");
                        int index = xy.toInt();
                        QString randomImage = imageFiles[index];
                        ui->test_image3->setPixmap(QPixmap(randomImage));
                        ui->test_image3->setScaledContents(true); // 이미지를 QLabel 크기에 맞춤
                    } else if (i == 3) {
                        ui->test_date4->setText(day);
                        ui->test_text4->setText("이 그림에 대한 당신의 감정은\n" + result + "입니다.");
                        int index = xy.toInt();
                        QString randomImage = imageFiles[index];
                        ui->test_image4->setPixmap(QPixmap(randomImage));
                        ui->test_image4->setScaledContents(true); // 이미지를 QLabel 크기에 맞춤
                    }
                }
            }
        }
    }
}

//[1] 로그인
void MainClient::on_btn_login_clicked() // 로그인 버튼을 눌렀을 떄
{
    QString id = ui->txt_id->toPlainText();
    QString pw = ui->txt_pw->toPlainText();

    QDataStream socketStream(tcpSocket);
    socketStream.setVersion(QDataStream::Qt_5_15);

    QString header = QString("Type:login,ID:%1,PW:%2;").arg(id).arg(pw);
    header.resize(1024);

    QByteArray byteArray = header.toUtf8();

    socketStream << byteArray;

    ui->txt_id->clear();
    ui->txt_pw->clear();
}
//[2] 회원가입
void MainClient::on_btn_sign_clicked() // 회원가입 버튼
{
    int targetIndex = 1; // 회원가입 인덱스
    ui->stackedWidget->setCurrentIndex(targetIndex);
}
//[2-1]
void MainClient::on_btn_sign_back_clicked()// 회원가입에서 메인으로 돌아가기
{
    int targetIndex = 0;
    ui->stackedWidget->setCurrentIndex(targetIndex);

    ui->txt_sign_id->clear();
    ui->txt_sign_pw->clear();
    ui->txt_sign_pw2->clear();
    ui->txt_sign_ph->clear();
    ui->txt_sign_ph2->clear();
    ui->txt_sign_name->clear();
    ui->btn_checknum->setEnabled(true);
}
//[2-2]
void MainClient::on_btn_checknum_clicked()
{
    QString phoneNumber = ui->txt_sign_ph->toPlainText();
    QRegularExpression regex("^[0-9]+$"); // 숫자로만 이루어진 문자열을 검사하기 위한 정규식

    if (regex.match(phoneNumber).hasMatch()) {
        // 입력이 있을 때 실행할 코드
        if(phoneNumber.size() == 11) // 번호가 11자리일 때
        {
            // 랜덤한 3자리 숫자 생성
            int randomCode = QRandomGenerator::global()->bounded(100, 999);
            // 랜덤한 숫자를 문자열로 변환하여 메시지 박스로 표시
            randomCodeStr = QString::number(randomCode); // 인증 번호
            QMessageBox::information(this, "인증번호", randomCodeStr);
            ui->btn_checknum->setEnabled(false);
        }
        else
        {
            QMessageBox::information(this, "번호", "11자리 숫자로 입력해주세요.");
        }
    } else {
        QMessageBox::information(this, "번호", "번호를 입력해주세요");
    }
}
//[2-3]
void MainClient::on_btn_sign_last_clicked() // 회원가입 id + pw + ph + name 전송
{
    QString id = ui->txt_sign_id->toPlainText();
    QString pw = ui->txt_sign_pw->toPlainText();
    QString pw2 = ui->txt_sign_pw2->toPlainText(); // 비밀번호 재확인
    QString ph = ui->txt_sign_ph->toPlainText();
    QString ph2 = ui->txt_sign_ph2->toPlainText(); // 인증번호
    QString name = ui->txt_sign_name->toPlainText();

    if (!id.isEmpty() && !pw.isEmpty() && !pw2.isEmpty() && !ph.isEmpty() && !ph2.isEmpty() && !name.isEmpty())
    {
        if(pw == pw2)
        {
            if(randomCodeStr == ph2)
            {
                QDataStream socketStream(tcpSocket);
                socketStream.setVersion(QDataStream::Qt_5_15);

                QString header = QString("Type:Sign,ID:%1,PW:%2,PH:%3,NAME:%4;").arg(id).arg(pw).arg(ph).arg(name);
                header.resize(1024);

                QByteArray byteArray = header.toUtf8();

                socketStream << byteArray;
            }
            else
            {
                QMessageBox::information(this, "인증번호", "인증번호를 재입력해주세요");
                ui->txt_sign_ph2->clear();
            }
        }
        else
        {
            QMessageBox::information(this, "비밀번호", "비밀번호를 재입력해주세요");
            ui->txt_sign_pw->clear();
            ui->txt_sign_pw2->clear();
        }
    }
    else
    {
        QMessageBox::information(this, "입력 필요", "입력을 전부 해주세요");
    }
}
// 아이디 찾기 [3-1]
void MainClient::on_btn_idfind_clicked() // 메인에서 아이디 찾기 버튼
{
    int targetIndex = 2;
    ui->stackedWidget->setCurrentIndex(targetIndex);
}
// [3-2]
void MainClient::on_btn_sign_back_2_clicked() // 아이디 찾기 화면에서 메인으로
{
    int targetIndex = 0;
    ui->stackedWidget->setCurrentIndex(targetIndex);

    ui->txt_find_id->clear();
    ui->txt_find_id2->clear();
    ui->btn_number->setEnabled(true);
}
// [3-3]
void MainClient::on_btn_number_clicked()
{
    QString phoneNumber = ui->txt_find_id->toPlainText();
    QRegularExpression regex("^[0-9]+$"); // 숫자로만 이루어진 문자열을 검사하기 위한 정규식

    if (regex.match(phoneNumber).hasMatch()) {
        // 입력이 있을 때 실행할 코드
        if(phoneNumber.size() ==  11) // 번호가 11자리일 때
        {
            // 랜덤한 3자리 숫자 생성
            int randomCode = QRandomGenerator::global()->bounded(100, 999);
            // 랜덤한 숫자를 문자열로 변환하여 메시지 박스로 표시
            randomCodeIdfind = QString::number(randomCode); // 인증 번호
            QMessageBox::information(this, "인증번호", randomCodeIdfind);
            ui->btn_number->setEnabled(false);
        } else {
            QMessageBox::information(this, "번호", "11자리 숫자로 입력해주세요.");
        }
    } else {
        QMessageBox::information(this, "번호", "번호를 입력해주세요");
    }
}
// [3-4]
void MainClient::on_btn_sign_last_2_clicked() // 아이디 찾기 버튼을 누르면
{
    QString ph = ui->txt_find_id->toPlainText();
    QString code = ui->txt_find_id2->toPlainText();

    if(randomCodeIdfind == code)
    {
        QDataStream socketStream(tcpSocket);
        socketStream.setVersion(QDataStream::Qt_5_15);

        QString header = QString("Type:IdFind,PH:%1;").arg(ph);
        header.resize(1024);

        QByteArray byteArray = header.toUtf8();

        socketStream << byteArray;
    }
    else
    {
        QMessageBox::information(this, "인증번호", "인증번호를 재입력해주세요");
        ui->txt_sign_ph2->clear();
    }
}
// [3-5]
void MainClient::on_btn_sign_back_3_clicked() // 아이디 찾은 후 돌아가는 버튼
{
    int targetIndex = 0;
    ui->stackedWidget->setCurrentIndex(targetIndex);
}
// 비밀번호 찾기[4-1]
void MainClient::on_btn_pw_find_clicked() // 비밀번호 찾기 버튼
{
    QString pw = ui->txt_pw_find->toPlainText();
    QString name = ui->txt_pw_find2->toPlainText();

    QDataStream socketStream(tcpSocket);
    socketStream.setVersion(QDataStream::Qt_5_15);

    QString header = QString("Type:Pwfind,PW:%1,NAME:%2;").arg(pw).arg(name);
    header.resize(1024);

    QByteArray byteArray = header.toUtf8();

    socketStream << byteArray;
}

void MainClient::on_btn_sign_back_4_clicked() // 비밀번호 찾기에서 뒤로가기 버튼
{
    int targetIndex = 0;
    ui->stackedWidget->setCurrentIndex(targetIndex);
    ui->txt_pw_find->clear();
    ui->txt_find_id2->clear();
}

void MainClient::on_btn_pwfind_clicked()
{
    int targetIndex = 4;
    ui->stackedWidget->setCurrentIndex(targetIndex);
}

int MainClient::showImage()
{
    // 이미지 파일 이름 목록
    imageFiles = {":/new/prefix1/image/image1.jpg", ":/new/prefix1/image/image2.jpg", ":/new/prefix1/image/image3.jpg", ":/new/prefix1/image/image4.jpg", ":/new/prefix1/image/image5.jpg", ":/new/prefix1/image/image6.jpg", ":/new/prefix1/image/image7.jpg", ":/new/prefix1/image/image8.jpg", ":/new/prefix1/image/image9.jpg"};

    // 이미지 파일 리스트의 모든 인덱스를 확인
    for (int i = 0; i < imageFiles.size(); ++i) {
        qDebug() << "인덱스" << i << " : " << imageFiles[i];
    }

    // 랜덤 이미지 선택
    int randomIndex = QRandomGenerator::global()->bounded(imageFiles.size());
    QString randomImage = imageFiles[randomIndex];

    // 이미지를 QLabel에 표시
    ui->lblImage->setPixmap(QPixmap(randomImage));
    ui->lblImage->setScaledContents(true); // 이미지를 QLabel 크기에 맞춤

    return randomIndex;
}

// 이미지 변경 시, 새로고침 같은거
void MainClient::on_btnImage_clicked()
{
    randomIndex = showImage();
}

// 전송버튼 클릭 시, 서버로 텍스트와 이미지인덱스 전송
void MainClient::on_btnSend_clicked()
{
    QString text = ui->txtWrite->text();

    QDataStream socketStream(tcpSocket);
    socketStream.setVersion(QDataStream::Qt_5_15);

    QString header = QString("Type:test, text:%1, randomIndex:%2;").arg(text).arg(randomIndex);
    header.resize(1024);

    qDebug() << text;
    qDebug() << randomIndex;

    QByteArray byteArray = header.toUtf8();

    socketStream << byteArray;

    qDebug() << header.toUtf8();

    ui->txtWrite->clear();

    ui->stackedWidget->setCurrentIndex(8);
    showResult();
}

void MainClient::showResult()
{
    // 이미지 파일 이름 목록
    imageFiles = {":/new/prefix1/image/image1.jpg", ":/new/prefix1/image/image2.jpg", ":/new/prefix1/image/image3.jpg", ":/new/prefix1/image/image4.jpg", ":/new/prefix1/image/image5.jpg", ":/new/prefix1/image/image6.jpg", ":/new/prefix1/image/image7.jpg", ":/new/prefix1/image/image8.jpg", ":/new/prefix1/image/image9.jpg"};

    // 랜덤 이미지 선택
    QString randomImage = imageFiles[randomIndex];

    // 이미지를 QLabel에 표시
    ui->lblImage_2->setPixmap(QPixmap(randomImage));
    ui->lblImage_2->setScaledContents(true); // 이미지를 QLabel 크기에 맞춤
}

void MainClient::information() // 내정보 누를 때 마다 실행
{
    ui->txt_sign_id_2->setText(user_id);
    ui->txt_sign_pw_2->setText(user_pw);
    ui->txt_sign_ph_2->setText(user_ph);
    ui->txt_sign_name_2->setText(user_name);
    ui->txt_day->setText(user_day);
}

// 검사화면->내정보
void MainClient::on_btnMyinfo_clicked()
{
    information();
    ui->stackedWidget->setCurrentIndex(5);
}

// 결과기록->내정보
void MainClient::on_btn_sign_back_7_clicked()
{
    information();
    ui->stackedWidget->setCurrentIndex(5);
}

// 결과화면->내정보
void MainClient::on_btnMyinfo1_clicked()
{
    information();
    ui->stackedWidget->setCurrentIndex(5);
}
void MainClient::on_btnMyinfo2_clicked()
{
    information();
    ui->stackedWidget->setCurrentIndex(5);
}

// 내정보화면->검사화면
void MainClient::on_btn_sign_back_5_clicked()
{
    ui->lblImage->clear();
    ui->txtWrite->clear();
    ui->stackedWidget->setCurrentIndex(7);
    clearResult();
}

// 결과화면->검사화면
void MainClient::on_btn_sign_back_6_clicked()
{
    ui->stackedWidget->setCurrentIndex(7);
    ui->lblImage->clear();
    ui->lblImage_2->clear();
    ui->txtWrite->clear();
    ui->result_txt->clear();
}

// 내정보->결과기록
void MainClient::on_btnRecord_clicked()
{
    ui->stackedWidget->setCurrentIndex(6);
}
void MainClient::on_pushButton_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(6);
}

void MainClient::clearResult()
{
    ui->test_date1->clear();
    ui->test_text1->clear();
    ui->test_image1->clear();

    ui->test_date2->clear();
    ui->test_text2->clear();
    ui->test_image2->clear();

    ui->test_date3->clear();
    ui->test_text3->clear();
    ui->test_image3->clear();

    ui->test_date4->clear();
    ui->test_text4->clear();
    ui->test_image4->clear();
}

// 로그아웃 // 결과화면->로그인화면
void MainClient::on_btnLogout1_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
    clearResult();
    tcpSocket->disconnected();
    tcpSocket=nullptr;
    initialize();
}

void MainClient::on_btnLogout2_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
    clearResult();
    tcpSocket->disconnected();
    tcpSocket=nullptr;
    initialize();
}

void MainClient::on_btnLogout3_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
    clearResult();
    tcpSocket->disconnected();
    tcpSocket=nullptr;
    initialize();
}


