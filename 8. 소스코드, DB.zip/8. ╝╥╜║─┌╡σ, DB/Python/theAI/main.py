import calc as func
import socket
from _thread import *

if __name__ == "__main__":

    # 소켓 선언
    client_sockets = []

    # 사용자의 IP 가져오기
    hostname = socket.gethostname()
    HOST = socket.gethostbyname(hostname)
    PORT = 9999

    # 서버 소켓 생성
    print('>> Server Start')
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    server_socket.listen()

    try:
        while True:
            print('>> Wait')
            client_socket, addr = server_socket.accept()
            client_sockets.append(client_socket)
            start_new_thread(func.threaded, (client_socket, addr))

    except Exception as e:
        print('에러는? : ', e)

    finally:
        func.resetCnt()
        func.db_conn.close()
        server_socket.close()