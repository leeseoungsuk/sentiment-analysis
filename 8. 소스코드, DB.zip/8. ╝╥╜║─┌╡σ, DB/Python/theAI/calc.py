from konlpy.tag import Kkma
import cv2
import math
import pymysql
from collections import Counter
import numpy as np

okt = Kkma()

db_conn = pymysql.connect(
    host='localhost',
    port=3306,
    user='root',
    passwd='0000',
    database='wordscore',
    charset='utf8')

def resetCnt():
    if db_conn.open:
        with db_conn.cursor() as curs:
            query = "UPDATE adjective set count = 0"
            curs.execute(query)
            curs.fetchall()
        db_conn.commit()

def print_angle_and_figure(shape_counter, shape_data, img):
    most_common_slope = None
    if shape_counter:
        most_common_shape, _ = shape_counter.most_common(1)[0]
    else:
        most_common_shape = "도형 없음"
    most_common_angle = None
    # 가장 많이 나타난 도형을 대표 도형으로 그리기
    for (shape_name, contour, (cX, cY)) in shape_data:
        if shape_name == most_common_shape:
            cv2.drawContours(img, [contour], -1, (0, 255, 0), 2)

            (x, y), (MA, ma), angle = cv2.fitEllipse(contour)
            most_common_angle = angle
            most_common_slope = math.tan(math.radians(angle))
    # 빈도 수가 가장 높은 도형의 각도 출력
    if most_common_shape != "도형 없음":
        print(f"빈도 수가 가장 높은 도형: {most_common_shape}, 각도: {most_common_angle}도, 기울기 : {most_common_slope}")
        imgNum = shape_initialize(most_common_shape, most_common_slope)
        return imgNum
    else:
        print("어떠한 도형도 검출되지 않았습니다.")

def shape_initialize(shape, slope):

    shapeNum = 0
    slopNum = 0

    slope = abs(slope)

    if slope == 0:
        slopNum = 0.7
    elif 0 < slope <= 15:
        slopNum = 0.6
    elif 15 < slope <= 30:
        slopNum = 0.3
    elif 30 < slope <= 45 or 60 < slope <= 75:
        slopNum = 0.1
    elif 45 < slope <= 60 or 75 < slope <= 90 or 105 < slope <= 120 or 150 < slope <= 179:
        slopNum = -0.1
    elif 90 < slope <= 105 or slope == 180:
        slopNum = 0.4
    elif 120 < slope <= 135:
        slopNum = -0.3
    elif 135 < slope <= 150:
        slopNum = -0.5

    if shape == "삼각형":
        shapeNum = -0.1
    if shape == "사각형":
        shapeNum = -0.5
    if shape == "원":
        shapeNum = 1.0
        return shapeNum

    return shapeNum + slopNum

def detected_image(img):
    # 배열 선언
    shape_data = []
    shape_names = []

    # 흑백처리
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # GaussianBlur 처리
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # Canny 알고리즘으로 가장자리
    edges = cv2.Canny(blurred, 100, 200)

    # findContours 함수로 윤곽선 찾기
    contours, _ = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # 반복문에 넣어서,
    for i, contour in enumerate(contours):
        area = cv2.contourArea(contour)

        # 작은 윤곽선들 무시
        if area < 500:
            continue
        epsilon = 0.045 * cv2.arcLength(contour, True)

        # approxPolyDP 함수로, 윤곽선 근사화/윤곽선 꼭짓점 수 확인 후 도형 식별
        approx = cv2.approxPolyDP(contour, epsilon, True)

        if len(approx) == 3:
            shape_name = "삼각형"
        elif len(approx) == 4:
            shape_name = "사각형"
        elif len(approx) > 5:
            shape_name = "원"
        else:
            shape_name = "알 수 없음"

        if shape_name != "알 수 없음":
            shape_names.append(shape_name)

            # 윤곽선 중심점 계산
            M = cv2.moments(contour)
            if M["m00"] != 0:
                cX = int(M["m10"] / M["m00"])
                cY = int(M["m01"] / M["m00"])
            else:
                cX, cY = 0, 0

            # 도형의 이름, 윤곽선, 중심점을 리스트에 추가합니다
            shape_data.append((shape_name, contour, (cX, cY)))

    shape_counter = Counter(shape_names)

    shape = print_angle_and_figure(shape_counter, shape_data, img)
    return shape

def Emotion(x, y, client_socket):

    header = "emotion:"
    print(x)
    print(y)

    # 비교할 수 있는 값일 떄 계산합니다
    if x is not None and y is not None:

        if x > 0 and y > 0:  # 1사분면
            if x == y:
                print("기대감, 즐거움")
                message = "기대감, 즐거움"
                combine = header + message
                client_socket.send(combine.encode())

            elif x > y:
                print("기대감")
                message = "기대감"
                combine = header + message
                client_socket.send(combine.encode())

            else:
                print("즐거움")
                message = "즐거움"
                combine = header + message
                client_socket.send(combine.encode())

        if x > 0 and y < 0:  # 4사분면
            if x == abs(y):
                print("화남, 역겨움")
                message = "화남, 역겨움"
                combine = header + message
                client_socket.send(combine.encode())

            elif x > abs(y):
                print("화남")
                message = "화남"
                combine = header + message
                client_socket.send(combine.encode())

            else:
                print("역겨움")
                message = "역겨움"
                combine = header + message
                client_socket.send(combine.encode())

        if x < 0 and y > 0:  # 2사분면
            if abs(x) == y:
                print("두려움, 신뢰")
                message = "두려움, 신뢰"
                combine = header + message
                client_socket.send(combine.encode())

            elif abs(x) > y:
                print("두려움")
                message = "두려움"
                combine = header + message
                client_socket.send(combine.encode())

            else:
                print("신뢰")
                message = "신뢰"
                combine = header + message
                client_socket.send(combine.encode())

        if x < 0 and y < 0:  # 3사분면
            if x == y:
                print("놀람, 슬픔")
                message = "놀람, 슬픔"
                combine = header + message
                client_socket.send(combine.encode())

            elif abs(x) > abs(y):
                print("놀람")
                message = "놀람"
                combine = header + message
                client_socket.send(combine.encode())

            else:
                print("슬픔")
                message = "슬픔"
                combine = header + message
                client_socket.send(combine.encode())

        if y == 0:
            if x > 0:
                print("기대감, 화남")
                message = "기대감, 화남"
                combine = header + message
                client_socket.send(combine.encode())

            else:
                print("두려움 ,놀람")
                message = "두려움 ,놀람"
                combine = header + message
                client_socket.send(combine.encode())

    # x 또는 y의 값이 None이기 때문에 인식이 안된다는 메시지 전송
    else:
        message = "end:"
        text = "감정이 인식되지 않습니다"
        print("감정이 인식되지 않습니다")
        combine = message + text
        client_socket.send(combine.encode())

    # 함수의 끝은 다음 요청을 위해서 단어 카운트를 0으로 초기화 하는 함수를 불러옴
    resetCnt()
    newVA = []

def PosNeg(Pos, Neg):
    if Pos > Neg:
        return Pos
    elif Pos == Neg:
        return 0
    else:
        return -Neg

def outputPosNeg():
    if db_conn.open:
        with db_conn.cursor() as curs:
            query1 = "SELECT PosScore FROM adjective WHERE count = (SELECT MAX(count) FROM adjective)"
            curs.execute(query1)
            result1 = curs.fetchall()  # 값이 같은 것 있으면 해당 수치를 전부 불러와서 저장한다
            maxPos = max(result1)  # 불러온 값 들 중 최고치만 뽑는다
            positive = maxPos[0] # 맨앞이 가장 큰 값을 나타낸다

            query2 = "SELECT NegScore FROM adjective WHERE count = (SELECT MAX(count) FROM adjective)"
            curs.execute(query2)
            result2 = curs.fetchall()
            maxNeg = max(result2)
            negative = maxNeg[0]

        db_conn.commit()

        # 텍스트의 값 구하기
        emotion = PosNeg(positive, negative)

        return emotion

def updateCount(client_socket, newVA):

    # 리스트에 형용사가 없다면 실행한다
    if not newVA:

        print(newVA)
        return None
    else:
        print("열림..")
        if db_conn.open:
            with db_conn.cursor() as curs:
                for i in range(len(newVA)):
                    query = "UPDATE adjective SET count = count + 1 WHERE adj = %s"
                    curs.execute(query, (newVA[i],))
                    curs.fetchall()

            db_conn.commit()

            return outputPosNeg()
        else:
            print('안 열림..')

# 시작 위치
def putADJ(adj, client_socket):
    newVA = []
    print(okt.pos(adj))

    #  for 문을 돌면서 Adjective에 해당하면 추가
    for word, type in okt.pos(adj):
        if type == "VA":
            newVA.append(word)
    return updateCount(client_socket, newVA)

def findImgWithNum(num):

    if db_conn.open:
        with db_conn.cursor() as curs:

            curs.execute(f"SELECT pic FROM pictures WHERE id = {num}")
            result = curs.fetchone()
            image_data = result[0]
            image_array = np.frombuffer(image_data, np.uint8)  # 이미지 데이터를 NumPy 배열로 변환
            img = cv2.imdecode(image_array, cv2.IMREAD_COLOR)  # OpenCV로 이미지로 읽어옴

        db_conn.commit()
        return img
    else:
        print('안 열림..')

# 쓰레드에서 실행되는 코드입니다.
# 접속한 클라이언트마다 새로운 쓰레드가 생성되어 통신을 하게 됩니다.
def threaded(client_socket, addr):
    print('>> Connected by :', addr[0], ':', addr[1])

    # 클라이언트가 접속을 끊을 때 까지 반복합니다.
    while True:

        try:
            # 데이터가 수신되면 클라이언트에 다시 전송합니다.(에코)
            data = client_socket.recv(1024)

            if not data:
                print('>> Disconnected by ' + addr[0], ':', addr[1])
                break

            print('>> Received from ' + addr[0], ':', addr[1], data.decode())

            # 받은 데이터를 ','로 나눈다
            split_by_comma = data.decode().split(',')

            # 이미지의 인덱스 값
            recv_data = split_by_comma[1].split(":")[1]

            # 이미지에 대한 리뷰 텍스트
            index = split_by_comma[2].split(":")[1].rstrip(";")

            # 받은 인덱스 값은 문자열이므로 int형으로 반환한다
            toInt = int(index)

            # 이미지의 데이터를 DB에서 가져온다
            img = findImgWithNum(toInt)

            # 이미지에 대한 기울기를 구해 기울기에 따른 값을 반환한다
            imgData = detected_image(img)

            # 이미지에 대한 텍스트 값의 형용사를 점수화 시켜 값을 반환한다
            textData = putADJ(recv_data, client_socket)

            # imgData = x, textData = y 로 놓고, 제 4사분면을 통해 감정을 판단한다
            Emotion(imgData, textData, client_socket)

        except ConnectionResetError as e:
            print('>> Disconnected by ' + addr[0], ':', addr[1])
            break
    client_socket.close()